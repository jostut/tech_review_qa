# Overview

This repository contains a technical exercise that is to be used for reference during a technical interview.
Be prepared to discuss the exercise, the expected results and how you came by them.

This is not production ready, there are many atypical and insecure implementations. 
Feel free to call us out on what you find ;)

## Tasks

1. Follow the instructions in the following folders.  
1. Be prepared to screenshare your work in the technical interview.
