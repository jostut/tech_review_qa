﻿namespace StargateAPI.Controllers
{
    public class SessionCookie
    {
        public int PersonId { get; set; }
    }
}